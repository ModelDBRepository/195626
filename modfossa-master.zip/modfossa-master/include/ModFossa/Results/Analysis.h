/* 
 * File:   Analysis.h
 * Author: gareth
 *
 * Created on March 29, 2013, 8:54 PM
 */

#ifndef ANALYSIS_H
#define	ANALYSIS_H

#include <ModFossa/Common/ContainerTypes.h>

namespace ModFossa{
class Analysis {
public:
    Analysis();
    ~Analysis();
    
private:

};
}
#endif	/* ANALYSIS_H */

