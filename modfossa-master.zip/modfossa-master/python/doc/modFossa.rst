modFossa Package
================

:mod:`modFossa` Package
-----------------------

.. automodule:: modFossa.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`experiment` Module
------------------------

.. automodule:: modFossa.experiment
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`globals` Module
---------------------

.. automodule:: modFossa.globals
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`markovModel` Module
-------------------------

.. automodule:: modFossa.markovModel
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`plotting` Module
----------------------

.. automodule:: modFossa.plotting
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`results` Module
---------------------

.. automodule:: modFossa.results
    :members:
    :undoc-members:
    :show-inheritance:

