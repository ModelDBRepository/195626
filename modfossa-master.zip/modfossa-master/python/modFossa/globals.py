import ModFossa

_modFossaCpp = ModFossa
_simulationRunner = ModFossa.simulationRunner()
_results = _simulationRunner.results()
_experiment = _simulationRunner.experiment()
markovModel = _experiment.markovModel()
