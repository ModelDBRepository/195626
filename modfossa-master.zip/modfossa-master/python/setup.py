from distutils.core import setup, Extension

if __name__ == '__main__':
    setup(name='ModFossa',
          version='0.1',
          packages=['modFossa'])
