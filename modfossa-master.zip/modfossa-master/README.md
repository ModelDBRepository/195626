# modfossa
*This document is a work in progress.*

For installation instructions, please see the INSTALL file.

The publication related to modfossa is available [here](http://www.cse.unr.edu/~fredh/papers/thesis/053-ferneyhough/thesis.pdf)
