#include <ModFossa/ModelDefinition/RateConstantBase.h>

namespace ModFossa {

RateConstantBase::RateConstantBase(void) {
}

RateConstantBase::~RateConstantBase(void) {
}
}