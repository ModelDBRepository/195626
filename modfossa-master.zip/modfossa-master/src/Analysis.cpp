/* 
 * File:   Analysis.cpp
 * Author: gareth
 * 
 * Created on March 29, 2013, 8:54 PM
 */

#include <ModFossa/Results/Analysis.h>

namespace ModFossa {
Analysis::Analysis() {
}

Analysis::~Analysis() {
}

}

